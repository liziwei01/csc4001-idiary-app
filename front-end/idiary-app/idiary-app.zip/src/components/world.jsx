import React from "react";

const World = () => {
  return <h1>World</h1>;
};

export default World;
